# Mercure VPN – application Android (version de test)

Application Android de Mercure VPN, écrite en Kotlin avec Jetpack Compose.

## Ce que contient cette version

- Activation de l'appareil par token `DEMS-USER-XXXX-XXXX-XXXX`
- ID unique de l'appareil `DEMS` + 16 caractères (identique après désinstallation ou effacement des données)
- Accueil : configuration active, bouton de connexion avec chronomètre, ping, données envoyées et reçues, débit, quota du forfait
- Activation d'un forfait par token `DEMS-DATA-XXXX-XXXX-XXXX`
- Historique avec filtres (Tout, Connexions, Activations)
- Profil, Alertes, Support (canal d'aide, tickets, questions fréquentes)
- Paramètres : reconnexion automatique, kill switch, réglages VPN Android, maintien en veille, thème clair/sombre/système, notifications, données locales, suppression du compte, déconnexion

**Important :** tant que le serveur Mercure n'est pas installé, la connexion VPN et le trafic sont **simulés**.
Les tokens sont seulement vérifiés sur leur format. Le bandeau « Version de test » l'indique dans l'application.

## Compiler l'APK

La compilation se fait automatiquement sur GitHub (fichier `.github/workflows/build-apk.yml`).
À chaque envoi de fichiers, GitHub compile l'APK et le publie dans l'onglet **Releases** du dépôt.

Sur un ordinateur, tu peux aussi ouvrir le dossier dans Android Studio et lancer `Build > Build APK(s)`.

## Réglages à modifier plus tard

- `app/src/main/java/com/mercure/vpn/Data.kt` : `SUPPORT_CHANNEL_URL` (lien Telegram ou WhatsApp)
- `app/build.gradle.kts` : `API_BASE_URL` (adresse du serveur, une fois installé)
- La clé de signature `app/mercure-test.jks` sert uniquement aux tests. Elle sera remplacée par une clé privée avant le lancement.
