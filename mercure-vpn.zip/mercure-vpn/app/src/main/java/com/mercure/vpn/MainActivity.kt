package com.mercure.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val store = AppStore.get(applicationContext)
        setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (store.theme) {
                "light" -> false
                "dark" -> true
                else -> systemDark
            }
            LaunchedEffect(dark) {
                val transparent = android.graphics.Color.TRANSPARENT
                val style = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            MercureTheme(dark) {
                MercureApp(store)
            }
        }
    }
}

enum class Tab { HOME, HISTORY, PROFILE, ALERTS }
enum class Overlay { FORFAIT, SUPPORT, SETTINGS }

@Composable
fun MercureApp(store: AppStore) {
    val p = LocalPalette.current
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var overlay by rememberSaveable { mutableStateOf<Overlay?>(null) }

    // Trafic : une mise à jour par seconde pendant la connexion.
    LaunchedEffect(store.connected) {
        while (store.connected) {
            delay(1000)
            store.tick()
        }
    }

    BackHandler(enabled = store.activated && (overlay != null || tab != Tab.HOME)) {
        if (overlay != null) overlay = null else tab = Tab.HOME
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .systemBarsPadding()
            .imePadding(),
    ) {
        if (!store.activated) {
            ActivationScreen(store)
        } else {
            val current = overlay
            if (current != null) {
                when (current) {
                    Overlay.FORFAIT -> ForfaitScreen(store, onBack = { overlay = null })
                    Overlay.SUPPORT -> SupportScreen(store, onBack = { overlay = null })
                    Overlay.SETTINGS -> SettingsScreen(
                        store = store,
                        onBack = { overlay = null },
                        openSupport = { overlay = Overlay.SUPPORT },
                        openHistory = { overlay = null; tab = Tab.HISTORY },
                        openForfait = { overlay = Overlay.FORFAIT },
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            Tab.HOME -> HomeScreen(
                                store = store,
                                openForfait = { overlay = Overlay.FORFAIT },
                                openSupport = { overlay = Overlay.SUPPORT },
                                openSettings = { overlay = Overlay.SETTINGS },
                                openHistory = { tab = Tab.HISTORY },
                            )
                            Tab.HISTORY -> HistoryScreen(store)
                            Tab.PROFILE -> ProfileScreen(
                                store = store,
                                openSettings = { overlay = Overlay.SETTINGS },
                                openForfait = { overlay = Overlay.FORFAIT },
                                openAlerts = { tab = Tab.ALERTS },
                            )
                            Tab.ALERTS -> AlertsScreen(store)
                        }
                    }
                    BottomBar(tab) { tab = it }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(selected: Tab, onSelect: (Tab) -> Unit) {
    val p = LocalPalette.current
    val items = listOf(
        Triple(Tab.HOME, "Accueil", Icons.Outlined.Home),
        Triple(Tab.HISTORY, "Historique", Icons.Outlined.History),
        Triple(Tab.PROFILE, "Profil", Icons.Outlined.Person),
        Triple(Tab.ALERTS, "Alertes", Icons.Outlined.Notifications),
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(p.surface)
            .padding(6.dp),
    ) {
        items.forEach { (t, label, icon) ->
            BarItem(label, icon, t == selected, Modifier.weight(1f)) { onSelect(t) }
        }
    }
}

@Composable
private fun BarItem(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(width = 52.dp, height = 36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) p.accent else p.surface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = if (selected) p.onAccent else p.muted, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            color = if (selected) p.text else p.muted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}
