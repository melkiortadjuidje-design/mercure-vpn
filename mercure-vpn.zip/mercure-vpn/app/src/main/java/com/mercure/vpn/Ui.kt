package com.mercure.vpn

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Couleurs ----------

data class Palette(
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val border: Color,
    val text: Color,
    val textSoft: Color,
    val muted: Color,
    val accent: Color,
    val onAccent: Color,
    val accentSoft: Color,
    val warn: Color,
    val warnSoft: Color,
    val danger: Color,
    val dangerSoft: Color,
    val isDark: Boolean,
)

val DarkPalette = Palette(
    bg = Color(0xFF0B0F17),
    surface = Color(0xFF131A26),
    surface2 = Color(0xFF1B2433),
    border = Color(0xFF263145),
    text = Color(0xFFE8EEF7),
    textSoft = Color(0xFFB6C2D3),
    muted = Color(0xFF8A97AB),
    accent = Color(0xFF2EE6A6),
    onAccent = Color(0xFF06251A),
    accentSoft = Color(0xFF12392D),
    warn = Color(0xFFFFC46B),
    warnSoft = Color(0xFF3A2A12),
    danger = Color(0xFFFF9F5A),
    dangerSoft = Color(0xFF3A2A22),
    isDark = true,
)

val LightPalette = Palette(
    bg = Color(0xFFF4F7FB),
    surface = Color(0xFFFFFFFF),
    surface2 = Color(0xFFE9EEF5),
    border = Color(0xFFD5DDE8),
    text = Color(0xFF0E1522),
    textSoft = Color(0xFF3B4A5E),
    muted = Color(0xFF5B6A80),
    accent = Color(0xFF0B7F58),
    onAccent = Color(0xFFFFFFFF),
    accentSoft = Color(0xFFD7F5EA),
    warn = Color(0xFF8A5700),
    warnSoft = Color(0xFFFFF0D6),
    danger = Color(0xFFB8400B),
    dangerSoft = Color(0xFFFDE7DC),
    isDark = false,
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

@Composable
fun MercureTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, surface = p.surface, onSurface = p.text, onBackground = p.text)
    } else {
        lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, surface = p.surface, onSurface = p.text, onBackground = p.text)
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

// ---------- Outils ----------

fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}

fun copyText(context: Context, label: String, text: String) {
    val cm = context.getSystemService(ClipboardManager::class.java)
    cm?.setPrimaryClip(ClipData.newPlainText(label, text))
    toast(context, "$label copié")
}

fun openIntent(context: Context, intent: Intent, fallback: String) {
    try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (e: Exception) {
        toast(context, fallback)
    }
}

fun openUrl(context: Context, url: String) {
    if (url.isBlank()) {
        toast(context, "Le lien du canal d'aide n'est pas encore configuré.")
        return
    }
    openIntent(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Impossible d'ouvrir le lien.")
}

// ---------- Composants ----------

@Composable
fun Logo(dp: Dp, color: Color) {
    Canvas(Modifier.size(dp)) {
        val r = this.size.minDimension
        val c = center
        drawCircle(color = color, radius = r * 0.22f, center = c)
        rotate(-25f, c) {
            drawOval(
                color = color,
                topLeft = Offset(c.x - r * 0.45f, c.y - r * 0.19f),
                size = Size(r * 0.9f, r * 0.38f),
                style = Stroke(width = r * 0.045f),
            )
        }
    }
}

@Composable
fun MCard(
    modifier: Modifier = Modifier,
    borderColor: Color? = null,
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(18.dp)
    val bordered = if (borderColor != null) Modifier.border(1.dp, borderColor, shape) else Modifier
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(p.surface)
            .then(bordered)
            .padding(padding),
        content = content,
    )
}

@Composable
fun SectionLabel(text: String) {
    val p = LocalPalette.current
    Text(
        text = text.uppercase(),
        color = p.muted,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 2.dp),
    )
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    val p = LocalPalette.current
    val fg = if (enabled) p.onAccent else p.muted
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) p.accent else p.surface2)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun OutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color? = null,
    icon: ImageVector? = null,
) {
    val p = LocalPalette.current
    val c = color ?: p.accent
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(shape)
            .border(1.dp, c.copy(alpha = 0.6f), shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = c, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SquareIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(p.surface)
            .clickable(role = Role.Button, onClickLabel = description, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = p.text, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun IconBadge(icon: ImageVector, tint: Color, background: Color, size: Dp = 40.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(background),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (onBack != null) {
            SquareIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Retour", onBack)
        }
        Text(
            title,
            color = p.text,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

@Composable
fun Pill(text: String, color: Color, background: Color, dot: Boolean = true) {
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(background)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (dot) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ProgressBar(fraction: Float, color: Color? = null) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .background(p.surface2),
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(CircleShape)
                .background(color ?: p.accent),
        )
    }
}

@Composable
fun RowDivider() {
    val p = LocalPalette.current
    Box(Modifier.fillMaxWidth().height(1.dp).background(p.surface2))
}

/** Une ligne de liste : icône, libellé, valeur, flèche. */
@Composable
fun ListRow(
    icon: ImageVector?,
    label: String,
    value: String? = null,
    labelColor: Color? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val p = LocalPalette.current
    val clickMod = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .then(clickMod)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (icon != null) {
            IconBadge(icon, tint = labelColor ?: p.accent, background = p.surface2, size = 38.dp)
        }
        Text(label, color = labelColor ?: p.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) {
            Text(
                value,
                color = p.muted,
                fontSize = 13.sp,
                textAlign = TextAlign.End,
                maxLines = 2,
                modifier = Modifier.widthIn(max = 160.dp),
            )
        }
        if (trailing != null) {
            trailing()
        } else if (onClick != null) {
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = p.muted)
        }
    }
}

@Composable
fun SwitchRow(icon: ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    ListRow(
        icon = icon,
        label = label,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = p.onAccent,
                    checkedTrackColor = p.accent,
                    uncheckedThumbColor = p.muted,
                    uncheckedTrackColor = p.surface2,
                    uncheckedBorderColor = p.border,
                ),
            )
        },
    )
}

/** Carte qui regroupe plusieurs lignes séparées par un trait. */
@Composable
fun RowGroup(content: @Composable ColumnScope.() -> Unit) {
    MCard(padding = 12.dp, content = content)
}

/** Champ de token avec mise en forme automatique (DEMS-USER-… / DEMS-DATA-…). */
@Composable
fun TokenField(value: TextFieldValue, onValueChange: (TextFieldValue) -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(14.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(
            color = p.text,
            fontFamily = FontFamily.Monospace,
            fontSize = 17.sp,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
        ),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Characters,
            autoCorrectEnabled = false,
            keyboardType = KeyboardType.Ascii,
        ),
        cursorBrush = SolidColor(p.accent),
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(p.surface)
            .border(1.dp, p.border, shape),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 58.dp)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                inner()
            }
        },
    )
}

/** Champ de texte simple avec texte d'aide. */
@Composable
fun InputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    minLines: Int = 1,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(14.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = minLines == 1,
        minLines = minLines,
        textStyle = TextStyle(color = p.text, fontSize = 15.sp),
        cursorBrush = SolidColor(p.accent),
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(p.bg)
            .border(1.dp, p.border, shape),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 50.dp)
                    .padding(horizontal = 14.dp, vertical = 14.dp),
            ) {
                if (value.isEmpty()) {
                    Text(placeholder, color = p.muted, fontSize = 15.sp)
                }
                inner()
            }
        },
    )
}
