package com.mercure.vpn

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.automirrored.outlined.List
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun tokenValue(kind: String): TextFieldValue {
    val text = Tokens.prefix(kind)
    return TextFieldValue(text, TextRange(text.length))
}

private fun formatTokenInput(input: TextFieldValue, kind: String): TextFieldValue {
    val text = Tokens.format(input.text, kind)
    return TextFieldValue(text, TextRange(text.length))
}

@Composable
private fun rememberNow(): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    return now
}

@Composable
private fun ConfirmDialog(
    title: String,
    text: String,
    confirm: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismiss: String? = "Annuler",
) {
    val p = LocalPalette.current
    val dismissContent: (@Composable () -> Unit)? =
        if (dismiss != null) @Composable { TextButton(onClick = onDismiss) { Text(dismiss, color = p.textSoft) } } else null
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirm, color = p.accent) }
        },
        dismissButton = dismissContent,
        title = { Text(title) },
        text = { Text(text) },
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.textSoft,
    )
}

@Composable
fun TutorialDialog(onDone: () -> Unit) {
    ConfirmDialog(
        title = "Bienvenue sur Mercure VPN",
        text = "1. Appuie sur le grand bouton pour te connecter.\n\n" +
            "2. Suis ton quota restant et ta date d'expiration sur l'accueil.\n\n" +
            "3. Quand ton forfait est épuisé, demande un token DEMS-DATA à ton revendeur et active-le avec « Activer un forfait ».\n\n" +
            "4. Besoin d'aide ? Ouvre « Support ».",
        confirm = "C'est compris",
        onConfirm = onDone,
        onDismiss = onDone,
        dismiss = null,
    )
}

// =====================================================================
// Activation de l'appareil
// =====================================================================

@Composable
fun ActivationScreen(store: AppStore) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var field by remember { mutableStateOf(tokenValue(Tokens.USER)) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Spacer(Modifier.height(16.dp))
        Logo(80.dp, p.accent)
        Text("Mercure VPN", color = p.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "Active ton appareil pour profiter d'une connexion privée et sécurisée.",
            color = p.muted,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(4.dp))

        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Token d'activation", color = p.textSoft, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            TokenField(field) { field = formatTokenInput(it, Tokens.USER); error = null }
            error?.let { Text(it, color = p.danger, fontSize = 13.sp) }
        }
        PrimaryButton(
            text = "Activer",
            enabled = Tokens.isComplete(field.text, Tokens.USER),
            onClick = { error = store.activateDevice(field.text) },
        )

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.weight(1f).height(1.dp).background(p.surface2))
            Text("ou", color = p.muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp))
            Box(Modifier.weight(1f).height(1.dp).background(p.surface2))
        }

        MCard {
            Text("ID de ton appareil", color = p.textSoft, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    store.deviceId,
                    color = p.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 15.sp,
                    modifier = Modifier.weight(1f),
                )
                Row(
                    modifier = Modifier
                        .heightIn(min = 44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.surface2)
                        .clickable(role = Role.Button) { copyText(ctx, "ID de l'appareil", store.deviceId) }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = null, tint = p.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Copier", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Pas de token ? Envoie cet ID à ton revendeur : il activera ton appareil à distance.",
                color = p.muted,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(12.dp))
            OutlineButton("Vérifier mon activation", onClick = { toast(ctx, store.checkRemoteActivation()) })
        }

        Text(
            "En activant, tu acceptes les conditions d'utilisation et la politique de confidentialité de Mercure VPN.",
            color = p.muted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
        )
    }
}

// =====================================================================
// Accueil
// =====================================================================

@Composable
fun HomeScreen(
    store: AppStore,
    openForfait: () -> Unit,
    openSupport: () -> Unit,
    openSettings: () -> Unit,
    openHistory: () -> Unit,
) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val now = rememberNow()
    val connected = store.connected
    val elapsed = if (connected) (now - store.connectedSince) / 1000 else 0L

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
    ) {
        // En-tête
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text("Bonjour", color = p.muted, fontSize = 14.sp)
                Text(store.userName, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            SquareIconButton(Icons.Outlined.Refresh, "Actualiser") { toast(ctx, store.refreshConfig()) }
            SquareIconButton(Icons.Outlined.Settings, "Paramètres", openSettings)
        }

        Column(
            modifier = Modifier.padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (store.isTestBuild) {
                MCard(borderColor = p.warn.copy(alpha = 0.5f), padding = 14.dp) {
                    Text(
                        "Version de test : la connexion est simulée tant que le serveur Mercure n'est pas installé.",
                        color = p.warn,
                        fontSize = 13.sp,
                    )
                }
            }

            // Configuration active
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.surface)
                    .clickable(onClick = openForfait)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                IconBadge(Icons.Outlined.VerifiedUser, tint = p.accent, background = p.accentSoft)
                Column(Modifier.weight(1f)) {
                    Text("Configuration active", color = p.muted, fontSize = 12.sp)
                    Text(
                        if (store.hasPlan()) store.planName else "Aucun forfait",
                        color = p.text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text("Changer", color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }

            // Statut + bouton de connexion
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Pill(
                    text = if (connected) "Protection active" else "Non protégé",
                    color = if (connected) p.accent else p.danger,
                    background = if (connected) p.accentSoft else p.dangerSoft,
                )
                ConnectButton(connected = connected, timer = formatDuration(elapsed)) {
                    store.toggleConnection()?.let { toast(ctx, it) }
                }
            }

            PrimaryButton(
                text = if (connected) "Se déconnecter" else "Se connecter",
                icon = Icons.Outlined.PowerSettingsNew,
                onClick = { store.toggleConnection()?.let { toast(ctx, it) } },
            )

            // Statistiques
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Ping", if (connected && store.pingMs > 0) "${store.pingMs} ms" else "—", Icons.Outlined.Speed, Modifier.weight(1f))
                StatTile("Envoyé", formatBytes(store.sessionSent), Icons.Outlined.ArrowUpward, Modifier.weight(1f))
                StatTile("Reçu", formatBytes(store.sessionReceived), Icons.Outlined.ArrowDownward, Modifier.weight(1f))
            }
            Text(
                if (connected) "Débit : ↑ ${formatRate(store.rateUp)}  ·  ↓ ${formatRate(store.rateDown)}" else "Débit : hors connexion",
                color = p.muted,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            QuotaCard(store)

            RowGroup {
                ListRow(Icons.AutoMirrored.Outlined.List, "Journal d'activité", onClick = openHistory)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile("Activer un forfait", Icons.Outlined.CardGiftcard, Modifier.weight(1f), openForfait)
                ActionTile("Support", Icons.Outlined.HeadsetMic, Modifier.weight(1f), openSupport)
            }

            Text(
                "Mercure VPN v${BuildConfig.VERSION_NAME}",
                color = p.muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }
    }

    if (!store.tutorialSeen) {
        TutorialDialog { store.markTutorialSeen() }
    }
}

@Composable
private fun ConnectButton(connected: Boolean, timer: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    val ring = if (connected) p.accent else p.border
    Box(Modifier.size(244.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(color = ring.copy(alpha = if (connected) 0.10f else 0.05f))
            drawCircle(color = ring.copy(alpha = 0.35f), radius = size.minDimension * 0.42f, style = Stroke(width = 2.dp.toPx()))
        }
        Column(
            modifier = Modifier
                .size(172.dp)
                .clip(CircleShape)
                .background(if (connected) p.accent else p.surface2)
                .clickable(
                    role = Role.Button,
                    onClickLabel = if (connected) "Se déconnecter du VPN" else "Se connecter au VPN",
                    onClick = onClick,
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            val fg = if (connected) p.onAccent else p.text
            Icon(Icons.Outlined.PowerSettingsNew, contentDescription = null, tint = fg, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(6.dp))
            Text(timer, color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(if (connected) "Connecté" else "Appuie pour connecter", color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    val p = LocalPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(p.surface)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(icon, contentDescription = null, tint = p.accent, modifier = Modifier.size(18.dp))
        Text(label, color = p.muted, fontSize = 12.sp)
        Text(value, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = modifier
            .heightIn(min = 100.dp)
            .clip(shape)
            .background(p.surface)
            .border(1.dp, p.surface2, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        IconBadge(icon, tint = p.accent, background = p.accentSoft, size = 44.dp)
        Spacer(Modifier.height(10.dp))
        Text(label, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun QuotaCard(store: AppStore) {
    val p = LocalPalette.current
    val fraction = store.planUsedFraction
    MCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "QUOTA DU FORFAIT",
                color = p.muted,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp,
                modifier = Modifier.weight(1f),
            )
            if (store.hasPlan()) Pill("VIP", p.warn, p.warnSoft, dot = false)
        }
        Spacer(Modifier.height(14.dp))
        if (!store.hasPlan()) {
            Text("Aucun forfait actif", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Active un token DEMS-DATA pour ajouter des gigaoctets.", color = p.muted, fontSize = 13.sp)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(formatBytes(store.planRemainingBytes), color = p.accent, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Text("restants", color = p.textSoft, fontSize = 14.sp)
                }
                Box(Modifier.size(92.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 8.dp.toPx()
                        val tl = Offset(w / 2, w / 2)
                        val sz = Size(size.width - w, size.height - w)
                        drawArc(color = p.surface2, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(w))
                        drawArc(color = p.accent, startAngle = -90f, sweepAngle = 360f * fraction, useCenter = false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${(fraction * 100).toInt()} %", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("utilisé", color = p.muted, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            ProgressBar(fraction)
            Spacer(Modifier.height(12.dp))
            Row {
                Text("${formatBytes(store.planUsedBytes)} utilisés", color = p.textSoft, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("${formatGb(store.planTotalGb)} au total", color = p.textSoft, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Expire le ${formatDate(store.planExpiry)} · ${daysLeft(store.planExpiry)} jours restants",
                color = p.muted,
                fontSize = 13.sp,
            )
        }
    }
}

// =====================================================================
// Activer un forfait
// =====================================================================

@Composable
fun ForfaitScreen(store: AppStore, onBack: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var field by remember { mutableStateOf(tokenValue(Tokens.DATA)) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("", onBack = onBack)
        Column(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Box(
                Modifier.size(100.dp).clip(CircleShape).background(p.accentSoft),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.CardGiftcard, contentDescription = null, tint = p.accent, modifier = Modifier.size(46.dp))
            }
            Text("Activer un forfait", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                "Saisis ton token data pour ajouter un forfait à ton appareil.",
                color = p.muted,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
            )
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Token data", color = p.textSoft, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                TokenField(field) { field = formatTokenInput(it, Tokens.DATA); error = null }
                error?.let { Text(it, color = p.danger, fontSize = 13.sp) }
            }
            PrimaryButton(
                text = "Activer le forfait",
                icon = Icons.Outlined.CardGiftcard,
                enabled = Tokens.isComplete(field.text, Tokens.DATA),
                onClick = {
                    val result = store.addPlan(field.text)
                    if (result == null) {
                        toast(ctx, "Forfait activé !")
                        onBack()
                    } else {
                        error = result
                    }
                },
            )
            MCard(padding = 14.dp) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.Info, contentDescription = null, tint = p.accent, modifier = Modifier.size(20.dp))
                    Text(
                        "Le token data (DEMS-DATA) ajoute des gigaoctets et une durée. Il est différent du token d'activation (DEMS-USER), qui autorise ce téléphone. Tu obtiens les deux auprès de ton revendeur.",
                        color = p.textSoft,
                        fontSize = 13.sp,
                    )
                }
            }
        }
    }
}

// =====================================================================
// Historique
// =====================================================================

@Composable
fun HistoryScreen(store: AppStore) {
    val p = LocalPalette.current
    var filter by rememberSaveable { mutableStateOf("all") }
    val items = store.events.filter { filter == "all" || it.type == filter }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Historique")
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("all" to "Tout", "vpn" to "Connexions", "act" to "Activations").forEach { (id, label) ->
                val selected = filter == id
                val shape = CircleShape
                Box(
                    modifier = Modifier
                        .heightIn(min = 44.dp)
                        .clip(shape)
                        .background(if (selected) p.accentSoft else Color.Transparent)
                        .border(1.dp, if (selected) p.accent else p.border, shape)
                        .clickable(role = Role.Tab) { filter = id }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, color = if (selected) p.accent else p.textSoft, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (items.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                IconBadge(Icons.Outlined.History, tint = p.muted, background = p.surface, size = 56.dp)
                Spacer(Modifier.height(14.dp))
                Text("Aucune activité enregistrée", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Les événements de ton compte apparaîtront ici.", color = p.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items.forEach { e ->
                    val (icon, tint) = when (e.type) {
                        "vpn" -> Icons.Outlined.Shield to p.accent
                        "act" -> Icons.Outlined.CardGiftcard to p.warn
                        else -> Icons.Outlined.History to p.textSoft
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.surface)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        IconBadge(icon, tint = tint, background = p.surface2)
                        Column(Modifier.weight(1f)) {
                            Text(e.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text(formatDateTime(e.time), color = p.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Profil
// =====================================================================

@Composable
fun ProfileScreen(
    store: AppStore,
    openSettings: () -> Unit,
    openForfait: () -> Unit,
    openAlerts: () -> Unit,
) {
    val p = LocalPalette.current
    var renaming by remember { mutableStateOf(false) }
    var showDevices by remember { mutableStateOf(false) }
    var confirmLogout by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenHeader("Profil") {
            SquareIconButton(Icons.Outlined.Settings, "Paramètres", openSettings)
        }
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.surface)
                    .clickable { renaming = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(p.accentSoft),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(store.userName.take(1).uppercase(), color = p.accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(store.userName, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Pill("Actif", p.accent, p.accentSoft)
                }
                Icon(Icons.Outlined.Edit, contentDescription = "Modifier le nom", tint = p.muted)
            }

            MCard {
                Text("Expiration de l'appareil", color = p.muted, fontSize = 13.sp)
                Text(formatDate(store.deviceExpiry), color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }

            MCard {
                Text("TON FORFAIT", color = p.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(12.dp))
                Row {
                    MiniStat(formatGb(store.planTotalGb), "Total", p.text, Modifier.weight(1f))
                    MiniStat(formatBytes(store.planUsedBytes), "Utilisé", p.text, Modifier.weight(1f))
                    MiniStat(formatBytes(store.planRemainingBytes), "Restant", p.accent, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                ProgressBar(store.planUsedFraction)
                Spacer(Modifier.height(10.dp))
                Text("Expiration du forfait : ${formatDate(store.planExpiry)}", color = p.muted, fontSize = 13.sp)
            }

            RowGroup {
                ListRow(Icons.Outlined.Person, "Informations personnelles", onClick = { renaming = true })
                RowDivider()
                ListRow(Icons.Outlined.Smartphone, "Appareils autorisés", value = "1 appareil", onClick = { showDevices = true })
                RowDivider()
                ListRow(Icons.Outlined.Shield, "Sécurité et connexion", onClick = openSettings)
                RowDivider()
                ListRow(Icons.Outlined.Notifications, "Notifications", onClick = openAlerts)
            }

            OutlineButton("Activer un forfait", onClick = openForfait, icon = Icons.Outlined.CardGiftcard)
            OutlineButton("Déconnexion", onClick = { confirmLogout = true }, color = p.danger, icon = Icons.AutoMirrored.Outlined.Logout)
            Text(
                "Mercure VPN v${BuildConfig.VERSION_NAME}",
                color = p.muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }

    if (renaming) RenameDialog(store.userName, onSave = { store.rename(it) }, onDismiss = { renaming = false })
    if (showDevices) {
        ConfirmDialog(
            title = "Appareils autorisés",
            text = "Cet appareil :\n${store.deviceId}\n\nActif jusqu'au ${formatDate(store.deviceExpiry)}.",
            confirm = "Fermer",
            onConfirm = {},
            onDismiss = { showDevices = false },
            dismiss = null,
        )
    }
    if (confirmLogout) {
        ConfirmDialog(
            title = "Se déconnecter ?",
            text = "Tu devras saisir à nouveau un token d'activation pour utiliser Mercure VPN sur ce téléphone.",
            confirm = "Déconnexion",
            onConfirm = { store.logout() },
            onDismiss = { confirmLogout = false },
        )
    }
}

@Composable
private fun MiniStat(value: String, label: String, color: Color, modifier: Modifier) {
    val p = LocalPalette.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = p.muted, fontSize = 12.sp)
    }
}

@Composable
private fun RenameDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onSave(name); onDismiss() }, enabled = name.isNotBlank()) { Text("Enregistrer", color = p.accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = p.textSoft) } },
        title = { Text("Ton nom") },
        text = { InputField(name, { name = it.take(30) }, "Ex. : Melkior") },
        containerColor = p.surface,
        titleContentColor = p.text,
        textContentColor = p.textSoft,
    )
}

// =====================================================================
// Alertes
// =====================================================================

@Composable
fun AlertsScreen(store: AppStore) {
    val p = LocalPalette.current
    val now = rememberNow()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenHeader("Alertes")
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!store.notifications) {
                AlertItem(Icons.Outlined.NotificationsOff, p.muted, p.surface2, "Notifications désactivées", "Réactive-les dans les paramètres pour recevoir les annonces et alertes.")
            }
            if (store.connected) {
                AlertItem(
                    Icons.Outlined.VerifiedUser, p.accent, p.accentSoft, "Protection active",
                    "Durée ${formatDuration((now - store.connectedSince) / 1000)} · ↑ ${formatRate(store.rateUp)} · ↓ ${formatRate(store.rateDown)}",
                    highlighted = true,
                )
            }
            AlertItem(Icons.Outlined.CheckCircle, p.accent, p.surface2, "Compte actif", "Ton appareil est actif jusqu'au ${formatDate(store.deviceExpiry)}.")
            if (store.hasPlan() && store.planUsedFraction >= 0.9f) {
                AlertItem(Icons.Outlined.Warning, p.warn, p.warnSoft, "Quota bientôt épuisé", "Il te reste ${formatBytes(store.planRemainingBytes)}. Pense à renouveler ton forfait.")
            }
            if (store.hasPlan() && daysLeft(store.planExpiry) <= 3) {
                AlertItem(Icons.Outlined.Event, p.warn, p.warnSoft, "Forfait bientôt expiré", "Ton forfait expire le ${formatDate(store.planExpiry)}.")
            }
            if (!store.hasPlan()) {
                AlertItem(Icons.Outlined.CardGiftcard, p.warn, p.warnSoft, "Aucun forfait", "Active un token DEMS-DATA pour te connecter.")
            }
            if (store.isTestBuild) {
                AlertItem(Icons.Outlined.Info, p.textSoft, p.surface2, "Version de test", "Les connexions et le trafic sont simulés en attendant le serveur Mercure.")
            }
        }
    }
}

@Composable
private fun AlertItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    badge: Color,
    title: String,
    body: String,
    highlighted: Boolean = false,
) {
    val p = LocalPalette.current
    MCard(borderColor = if (highlighted) p.accent.copy(alpha = 0.5f) else null, padding = 14.dp) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconBadge(icon, tint = tint, background = badge)
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(body, color = p.textSoft, fontSize = 13.sp)
            }
        }
    }
}

// =====================================================================
// Support
// =====================================================================

private val FAQ = listOf(
    "Comment activer mon appareil ?" to "Saisis le token d'activation (DEMS-USER-…) reçu de ton revendeur, ou envoie-lui l'ID de ton appareil (DEMS…) pour qu'il t'active à distance.",
    "Comment ajouter un forfait ?" to "Ouvre « Activer un forfait » depuis l'accueil ou le profil, puis saisis ton token data (DEMS-DATA-…).",
    "Que faire si ma connexion ne fonctionne pas ?" to "Vérifie ta connexion Internet, puis utilise « Actualiser la configuration » dans les paramètres. Si le problème continue, crée un ticket.",
    "Mon forfait est expiré, que faire ?" to "Contacte ton revendeur pour obtenir un nouveau token data, puis active-le dans l'application.",
)

@Composable
fun SupportScreen(store: AppStore, onBack: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var subject by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf("") }
    var open by rememberSaveable { mutableIntStateOf(-1) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenHeader("Support", onBack = onBack)
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.surface)
                    .border(1.dp, p.accent.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                    .clickable { openUrl(ctx, SUPPORT_CHANNEL_URL) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                IconBadge(Icons.AutoMirrored.Outlined.Send, tint = p.accent, background = p.accentSoft)
                Column(Modifier.weight(1f)) {
                    Text("Ouvrir le canal d'aide", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("Annonces et aide rapide, même sans compte activé.", color = p.muted, fontSize = 13.sp)
                }
                Icon(Icons.Outlined.OpenInNew, contentDescription = null, tint = p.accent)
            }

            SectionLabel("Nous contacter")
            MCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    InputField(subject, { subject = it.take(80) }, "Sujet")
                    InputField(message, { message = it.take(1000) }, "Décris ton problème…", minLines = 4)
                    PrimaryButton(
                        text = "Envoyer",
                        icon = Icons.AutoMirrored.Outlined.Send,
                        enabled = subject.isNotBlank() && message.isNotBlank(),
                        onClick = {
                            store.addTicket(subject, message)
                            subject = ""
                            message = ""
                            toast(ctx, if (store.isTestBuild) "Ticket enregistré (version de test)." else "Ticket envoyé.")
                        },
                    )
                }
            }

            SectionLabel("Mes tickets")
            if (store.tickets.isEmpty()) {
                MCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.Inbox, contentDescription = null, tint = p.muted, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Tu n'as encore aucun ticket.", color = p.muted, fontSize = 14.sp)
                    }
                }
            } else {
                store.tickets.forEach { t ->
                    MCard(padding = 14.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.subject, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(formatDateTime(t.time), color = p.muted, fontSize = 12.sp)
                            }
                            Pill("En attente", p.warn, p.warnSoft, dot = false)
                        }
                    }
                }
            }

            SectionLabel("Questions fréquentes")
            MCard(padding = 8.dp) {
                FAQ.forEachIndexed { i, (q, a) ->
                    if (i > 0) RowDivider()
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { open = if (open == i) -1 else i }
                            .padding(horizontal = 8.dp, vertical = 14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.AutoMirrored.Outlined.HelpOutline, contentDescription = null, tint = p.accent, modifier = Modifier.size(20.dp))
                            Text(q, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Icon(
                                if (open == i) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                                contentDescription = null,
                                tint = p.muted,
                            )
                        }
                        if (open == i) {
                            Spacer(Modifier.height(8.dp))
                            Text(a, color = p.textSoft, fontSize = 13.sp, modifier = Modifier.padding(start = 30.dp))
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Paramètres
// =====================================================================

@Composable
fun SettingsScreen(
    store: AppStore,
    onBack: () -> Unit,
    openSupport: () -> Unit,
    openHistory: () -> Unit,
    openForfait: () -> Unit,
) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenHeader("Paramètres", onBack = onBack)
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {

            MCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(p.accentSoft),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(store.userName.take(1).uppercase(), color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(store.userName, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Pill(if (store.connected) "Connecté" else "Actif", p.accent, p.accentSoft)
                    }
                }
            }

            SectionLabel("Accès de cet appareil")
            RowGroup {
                ListRow(Icons.Outlined.Smartphone, "Expiration de l'appareil", value = formatDate(store.deviceExpiry))
                RowDivider()
                ListRow(Icons.Outlined.Key, "Saisir un nouveau token d'activation", onClick = { dialog = "newToken" })
            }

            SectionLabel("Ton forfait")
            RowGroup {
                ListRow(Icons.Outlined.DataUsage, "Utilisé", value = "${formatBytes(store.planUsedBytes)} / ${formatGb(store.planTotalGb)}")
                RowDivider()
                ListRow(Icons.Outlined.Event, "Expiration du forfait", value = formatDate(store.planExpiry))
                RowDivider()
                ListRow(Icons.Outlined.CardGiftcard, "Activer un forfait", onClick = openForfait)
            }

            SectionLabel("VPN")
            RowGroup {
                SwitchRow(Icons.Outlined.Sync, "Reconnexion automatique", store.autoReconnect) { store.setAutoReconnect(it) }
                RowDivider()
                SwitchRow(Icons.Outlined.Shield, "Kill switch", store.killSwitch) { store.setKillSwitch(it) }
                RowDivider()
                ListRow(Icons.Outlined.CloudDownload, "Actualiser la configuration", onClick = { toast(ctx, store.refreshConfig()) })
            }

            SectionLabel("Protection Android complémentaire")
            RowGroup {
                ListRow(Icons.Outlined.Lock, "Ouvrir les réglages VPN Android", onClick = {
                                            openIntent(ctx, Intent(Settings.ACTION_VPN_SETTINGS), "Réglages VPN introuvables sur ce téléphone.")
                                        })
            }
            Text(
                "Facultatif : dans les réglages VPN d'Android, active « VPN permanent » et « Bloquer les connexions sans VPN » pour Mercure. Si le VPN est indisponible, Android coupera alors Internet. L'application ne modifie jamais ces choix.",
                color = p.muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 4.dp),
            )

            SectionLabel("Arrière-plan")
            RowGroup {
                ListRow(Icons.Outlined.BatteryChargingFull, "Maintien du tunnel en veille", value = "Optimisation batterie", onClick = {
                                            openIntent(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), "Réglage introuvable sur ce téléphone.")
                                        })
            }
            Text(
                "Choisis « Sans restriction » pour Mercure VPN afin que le tunnel reste actif écran éteint.",
                color = p.muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 4.dp),
            )

            SectionLabel("Sécurité")
            RowGroup {
                ListRow(
                                            Icons.Outlined.PhoneAndroid,
                                            "ID de l'appareil",
                                            value = store.deviceId,
                                            onClick = { copyText(ctx, "ID de l'appareil", store.deviceId) },
                                            trailing = { Icon(Icons.Outlined.ContentCopy, contentDescription = "Copier", tint = p.accent) },
                                        )
            }

            SectionLabel("Apparence et langue")
            MCard(padding = 12.dp) {
                Text("Thème", color = p.text, fontSize = 15.sp, modifier = Modifier.padding(4.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple("system", "Système", Icons.Outlined.PhoneAndroid),
                        Triple("light", "Clair", Icons.Outlined.LightMode),
                        Triple("dark", "Sombre", Icons.Outlined.DarkMode),
                    ).forEach { (id, label, icon) ->
                        val selected = store.theme == id
                        val shape = RoundedCornerShape(14.dp)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 64.dp)
                                .clip(shape)
                                .background(if (selected) p.accentSoft else p.surface2)
                                .border(1.dp, if (selected) p.accent else Color.Transparent, shape)
                                .clickable(role = Role.RadioButton) { store.setThemeMode(id) }
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(icon, contentDescription = null, tint = if (selected) p.accent else p.textSoft)
                            Spacer(Modifier.height(4.dp))
                            Text(label, color = if (selected) p.accent else p.textSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                RowDivider()
                ListRow(Icons.Outlined.Language, "Langue", value = "Français")
                RowDivider()
                ListRow(Icons.Outlined.School, "Revoir le tutoriel", onClick = { dialog = "tutorial" })
            }

            SectionLabel("Notifications")
            RowGroup {
                SwitchRow(Icons.Outlined.Notifications, "Annonces, mises à jour et alertes", store.notifications) { store.setNotifications(it) }
            }

            SectionLabel("Données locales")
            RowGroup {
                ListRow(Icons.Outlined.Folder, "Données stockées", value = formatBytes(store.storageBytes()))
                RowDivider()
                ListRow(Icons.Outlined.DeleteOutline, "Effacer les données locales", labelColor = p.danger, onClick = { dialog = "clear" })
            }

            SectionLabel("À propos")
            RowGroup {
                ListRow(Icons.Outlined.Info, "Version de l'application", value = BuildConfig.VERSION_NAME)
                RowDivider()
                ListRow(Icons.Outlined.Code, "Build", value = BuildConfig.VERSION_CODE.toString())
                RowDivider()
                ListRow(Icons.Outlined.HeadsetMic, "Support", onClick = openSupport)
                RowDivider()
                ListRow(Icons.AutoMirrored.Outlined.List, "Journal d'activité", onClick = openHistory)
                RowDivider()
                ListRow(Icons.Outlined.Policy, "VPN et confidentialité", onClick = { dialog = "privacy" })
                RowDivider()
                ListRow(Icons.Outlined.DeleteOutline, "Demander la suppression du compte et des données", onClick = { dialog = "delete" })
            }

            Spacer(Modifier.height(8.dp))
            OutlineButton("Déconnexion", onClick = { dialog = "logout" }, color = p.danger, icon = Icons.AutoMirrored.Outlined.Logout)
            Text(
                "MERCURE VPN",
                color = p.muted,
                fontSize = 12.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            )
        }
    }

    when (dialog) {
        "tutorial" -> TutorialDialog { dialog = null }
        "newToken" -> ConfirmDialog(
            title = "Nouveau token d'activation",
            text = "L'appareil sera déconnecté et tu pourras saisir un nouveau token DEMS-USER.",
            confirm = "Continuer",
            onConfirm = { store.logout() },
            onDismiss = { dialog = null },
        )
        "clear" -> ConfirmDialog(
            title = "Effacer les données locales ?",
            text = "Le journal, les tickets et les réglages enregistrés sur ce téléphone seront supprimés. L'ID de l'appareil ne change pas.",
            confirm = "Effacer",
            onConfirm = { store.clearLocalData() },
            onDismiss = { dialog = null },
        )
        "privacy" -> ConfirmDialog(
            title = "VPN et confidentialité",
            text = "Mercure VPN chiffre ta connexion entre ton téléphone et nos serveurs. Nous n'enregistrons pas les sites que tu visites. Nous conservons uniquement l'ID de ton appareil, ton forfait et la quantité de données consommées, pour gérer ton abonnement.",
            confirm = "Fermer",
            onConfirm = {},
            onDismiss = { dialog = null },
            dismiss = null,
        )
        "delete" -> ConfirmDialog(
            title = "Supprimer le compte ?",
            text = "Une demande de suppression du compte et des données liées à l'appareil ${store.deviceId} sera envoyée au support.",
            confirm = "Envoyer la demande",
            onConfirm = {
                store.requestDeletion()
                toast(ctx, "Demande envoyée au support.")
            },
            onDismiss = { dialog = null },
        )
        "logout" -> ConfirmDialog(
            title = "Se déconnecter ?",
            text = "Tu devras saisir à nouveau un token d'activation pour utiliser Mercure VPN sur ce téléphone.",
            confirm = "Déconnexion",
            onConfirm = { store.logout() },
            onDismiss = { dialog = null },
        )
    }
}
