package com.mercure.vpn

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** Alphabet sans caractères ambigus (pas de O, 0, I, 1). 32 symboles. */
const val CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

/** Lien du canal d'aide (Telegram, WhatsApp...). Vide = pas encore configuré. */
const val SUPPORT_CHANNEL_URL = ""

private const val GB = 1_000_000_000L
private const val DAY = 24L * 60 * 60 * 1000

/**
 * Identifiant unique de l'appareil : DEMS + 16 caractères.
 * Calculé à partir de l'ANDROID_ID : il reste identique après une désinstallation,
 * une réinstallation ou un effacement des données (tant que l'APK est signé avec la même clé).
 * Il ne change qu'après une réinitialisation d'usine du téléphone.
 */
object DeviceId {
    private const val SALT = "mercure-vpn-device-v1"

    @SuppressLint("HardwareIds")
    fun get(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "inconnu"
        val digest = MessageDigest.getInstance("SHA-256").digest("$SALT:$androidId".toByteArray(Charsets.UTF_8))
        val sb = StringBuilder("DEMS")
        for (i in 0 until 16) {
            sb.append(CODE_ALPHABET[(digest[i].toInt() and 0xFF) % CODE_ALPHABET.length])
        }
        return sb.toString()
    }
}

/** Tokens : DEMS-USER-XXXX-XXXX-XXXX (activation) et DEMS-DATA-XXXX-XXXX-XXXX (forfait). */
object Tokens {
    const val USER = "USER"
    const val DATA = "DATA"

    fun prefix(kind: String) = "DEMS-$kind-"

    /** Met en forme la saisie : majuscules, préfixe fixe, tirets tous les 4 caractères. */
    fun format(raw: String, kind: String): String {
        val clean = raw.uppercase(Locale.ROOT).filter { it in 'A'..'Z' || it in '0'..'9' }
        val head = "DEMS$kind"
        val body = when {
            clean.startsWith(head) -> clean.substring(head.length)
            head.startsWith(clean) -> ""
            else -> clean
        }.take(12)
        return prefix(kind) + body.chunked(4).joinToString("-")
    }

    fun isComplete(value: String, kind: String): Boolean =
        Regex("^DEMS-$kind-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$").matches(value)

    fun mask(value: String): String =
        if (value.length >= 14) value.substring(0, 14) + "••••-••••" else value
}

data class Event(val type: String, val title: String, val time: Long)
data class Ticket(val subject: String, val message: String, val time: Long)

/**
 * État de l'application, enregistré sur le téléphone.
 * Version de test : tant que API_BASE_URL est vide, l'activation et la connexion sont simulées.
 */
class AppStore private constructor(private val context: Context) {

    companion object {
        private const val PREFS = "mercure"
        @Volatile private var instance: AppStore? = null

        fun get(context: Context): AppStore =
            instance ?: synchronized(this) {
                instance ?: AppStore(context.applicationContext).also { instance = it }
            }
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val deviceId: String = DeviceId.get(context)
    val isTestBuild: Boolean = BuildConfig.API_BASE_URL.isBlank()

    var activated by mutableStateOf(false)
        private set
    var userName by mutableStateOf("Client Mercure")
        private set
    var deviceExpiry by mutableLongStateOf(0L)
        private set

    var planName by mutableStateOf("")
        private set
    var planTotalGb by mutableStateOf(0.0)
        private set
    var planUsedBytes by mutableLongStateOf(0L)
        private set
    var planExpiry by mutableLongStateOf(0L)
        private set

    var connected by mutableStateOf(false)
        private set
    var connectedSince by mutableLongStateOf(0L)
        private set
    var sessionSent by mutableLongStateOf(0L)
        private set
    var sessionReceived by mutableLongStateOf(0L)
        private set
    var rateUp by mutableLongStateOf(0L)
        private set
    var rateDown by mutableLongStateOf(0L)
        private set
    var pingMs by mutableIntStateOf(0)
        private set

    var autoReconnect by mutableStateOf(true)
        private set
    var killSwitch by mutableStateOf(false)
        private set
    var notifications by mutableStateOf(true)
        private set
    var theme by mutableStateOf("system")
        private set
    var tutorialSeen by mutableStateOf(false)
        private set

    val events = mutableStateListOf<Event>()
    val tickets = mutableStateListOf<Ticket>()

    private var tickCount = 0

    init {
        load()
    }

    // ---------- Lecture / écriture ----------

    private fun load() {
        activated = prefs.getBoolean("activated", false)
        userName = prefs.getString("userName", "Client Mercure") ?: "Client Mercure"
        deviceExpiry = prefs.getLong("deviceExpiry", 0L)
        planName = prefs.getString("planName", "") ?: ""
        planTotalGb = prefs.getFloat("planTotalGb", 0f).toDouble()
        planUsedBytes = prefs.getLong("planUsedBytes", 0L)
        planExpiry = prefs.getLong("planExpiry", 0L)
        autoReconnect = prefs.getBoolean("autoReconnect", true)
        killSwitch = prefs.getBoolean("killSwitch", false)
        notifications = prefs.getBoolean("notifications", true)
        theme = prefs.getString("theme", "system") ?: "system"
        tutorialSeen = prefs.getBoolean("tutorialSeen", false)

        events.clear()
        runCatching {
            val arr = JSONArray(prefs.getString("events", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                events.add(Event(o.getString("type"), o.getString("title"), o.getLong("time")))
            }
        }
        tickets.clear()
        runCatching {
            val arr = JSONArray(prefs.getString("tickets", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                tickets.add(Ticket(o.getString("subject"), o.getString("message"), o.getLong("time")))
            }
        }

        // Reconnexion automatique : on reprend la session si elle était active.
        val wasConnected = prefs.getBoolean("connected", false)
        if (wasConnected && autoReconnect && activated && hasUsablePlan()) {
            connected = true
            connectedSince = prefs.getLong("connectedSince", System.currentTimeMillis())
        }
    }

    private fun save() {
        val ev = JSONArray()
        events.take(100).forEach {
            ev.put(JSONObject().put("type", it.type).put("title", it.title).put("time", it.time))
        }
        val tk = JSONArray()
        tickets.take(50).forEach {
            tk.put(JSONObject().put("subject", it.subject).put("message", it.message).put("time", it.time))
        }
        prefs.edit()
            .putBoolean("activated", activated)
            .putString("userName", userName)
            .putLong("deviceExpiry", deviceExpiry)
            .putString("planName", planName)
            .putFloat("planTotalGb", planTotalGb.toFloat())
            .putLong("planUsedBytes", planUsedBytes)
            .putLong("planExpiry", planExpiry)
            .putBoolean("connected", connected)
            .putLong("connectedSince", connectedSince)
            .putBoolean("autoReconnect", autoReconnect)
            .putBoolean("killSwitch", killSwitch)
            .putBoolean("notifications", notifications)
            .putString("theme", theme)
            .putBoolean("tutorialSeen", tutorialSeen)
            .putString("events", ev.toString())
            .putString("tickets", tk.toString())
            .apply()
    }

    private fun log(type: String, title: String) {
        events.add(0, Event(type, title, System.currentTimeMillis()))
        while (events.size > 100) events.removeAt(events.size - 1)
    }

    private fun usedTokens(): Set<String> = prefs.getStringSet("usedTokens", emptySet()) ?: emptySet()

    private fun markUsed(token: String) {
        val set = usedTokens().toMutableSet()
        set.add(token)
        prefs.edit().putStringSet("usedTokens", set).apply()
    }

    // ---------- Forfait ----------

    val planTotalBytes: Long get() = (planTotalGb * GB).toLong()
    val planRemainingBytes: Long get() = (planTotalBytes - planUsedBytes).coerceAtLeast(0L)
    val planUsedFraction: Float
        get() = if (planTotalBytes <= 0L) 0f else (planUsedBytes.toFloat() / planTotalBytes.toFloat()).coerceIn(0f, 1f)

    fun hasPlan(): Boolean = planTotalGb > 0.0

    fun hasUsablePlan(): Boolean =
        hasPlan() && planExpiry > System.currentTimeMillis() && planRemainingBytes > 0L

    // ---------- Actions ----------

    /** Renvoie null si tout va bien, sinon un message d'erreur. */
    fun activateDevice(token: String): String? {
        if (!Tokens.isComplete(token, Tokens.USER)) return "Le token doit être au format DEMS-USER-XXXX-XXXX-XXXX."
        if (usedTokens().contains(token)) return "Ce token a déjà été utilisé."
        markUsed(token)
        val now = System.currentTimeMillis()
        activated = true
        deviceExpiry = now + 30 * DAY
        if (!hasPlan()) {
            planName = "Essai gratuit 2 Go"
            planTotalGb = 2.0
            planUsedBytes = 0L
            planExpiry = now + 3 * DAY
            log("act", "Forfait ajouté : $planName")
        }
        log("act", "Appareil activé avec le token ${Tokens.mask(token)}")
        save()
        return null
    }

    fun checkRemoteActivation(): String =
        if (isTestBuild) "Version de test : aucun serveur n'est encore relié. L'activation à distance par ID fonctionnera dès que le serveur sera installé."
        else "Vérification en cours…"

    fun addPlan(token: String): String? {
        if (!Tokens.isComplete(token, Tokens.DATA)) return "Le token doit être au format DEMS-DATA-XXXX-XXXX-XXXX."
        if (usedTokens().contains(token)) return "Ce token a déjà été utilisé."
        markUsed(token)
        planName = "Forfait 50 Go"
        planTotalGb = 50.0
        planUsedBytes = 0L
        planExpiry = System.currentTimeMillis() + 30 * DAY
        log("act", "Forfait ajouté : $planName")
        save()
        return null
    }

    fun toggleConnection(): String? {
        if (connected) {
            disconnect(null)
            return null
        }
        if (!hasPlan()) return "Aucun forfait actif. Active un forfait pour te connecter."
        if (planExpiry <= System.currentTimeMillis()) return "Ton forfait a expiré. Active un nouveau forfait."
        if (planRemainingBytes <= 0L) return "Ton quota est épuisé. Active un nouveau forfait."
        connected = true
        connectedSince = System.currentTimeMillis()
        sessionSent = 0L
        sessionReceived = 0L
        pingMs = 0
        log("vpn", "Connexion au VPN")
        save()
        return null
    }

    private fun disconnect(reason: String?) {
        val seconds = (System.currentTimeMillis() - connectedSince) / 1000
        connected = false
        rateUp = 0L
        rateDown = 0L
        log("vpn", (reason ?: "Déconnexion") + " · durée " + formatDuration(seconds))
        save()
    }

    /** Appelé chaque seconde pendant la connexion (trafic simulé en version de test). */
    fun tick() {
        if (!connected) return
        val up = Random.nextLong(2_000L, 60_000L)
        val down = Random.nextLong(20_000L, 900_000L)
        sessionSent += up
        sessionReceived += down
        rateUp = up
        rateDown = down
        pingMs = Random.nextInt(38, 96)
        planUsedBytes += up + down
        if (planUsedBytes >= planTotalBytes) {
            planUsedBytes = planTotalBytes
            disconnect("Quota épuisé")
            return
        }
        if (planExpiry <= System.currentTimeMillis()) {
            disconnect("Forfait expiré")
            return
        }
        tickCount++
        if (tickCount % 5 == 0) save()
    }

    fun refreshConfig(): String {
        log("cpt", "Configuration actualisée · quota restant ${formatBytes(planRemainingBytes)}")
        save()
        return if (isTestBuild) "Configuration à jour (version de test)." else "Configuration à jour."
    }

    fun rename(name: String) {
        val clean = name.trim().take(30)
        if (clean.isNotEmpty()) {
            userName = clean
            save()
        }
    }

    fun setAutoReconnect(v: Boolean) { autoReconnect = v; save() }
    fun setKillSwitch(v: Boolean) { killSwitch = v; save() }
    fun setNotifications(v: Boolean) { notifications = v; save() }
    fun setThemeMode(v: String) { theme = v; save() }
    fun markTutorialSeen() { tutorialSeen = true; save() }

    fun addTicket(subject: String, message: String) {
        tickets.add(0, Ticket(subject.trim(), message.trim(), System.currentTimeMillis()))
        log("cpt", "Ticket envoyé : ${subject.trim()}")
        save()
    }

    fun requestDeletion() {
        addTicket("Suppression du compte", "Demande de suppression du compte et des données de l'appareil $deviceId.")
    }

    fun logout() {
        if (connected) disconnect(null)
        activated = false
        log("cpt", "Déconnexion de l'appareil")
        save()
    }

    fun clearLocalData() {
        prefs.edit().clear().apply()
        connected = false
        rateUp = 0L
        rateDown = 0L
        load()
    }

    fun storageBytes(): Long =
        File(context.applicationInfo.dataDir, "shared_prefs/$PREFS.xml").let { if (it.exists()) it.length() else 0L }
}

// ---------- Mise en forme ----------

fun formatBytes(b: Long): String = when {
    b >= 1_000_000_000L -> String.format(Locale.FRANCE, "%.1f Go", b / 1e9)
    b >= 1_000_000L -> String.format(Locale.FRANCE, "%.1f Mo", b / 1e6)
    b >= 1_000L -> String.format(Locale.FRANCE, "%.0f ko", b / 1e3)
    else -> "$b o"
}

fun formatRate(b: Long): String = formatBytes(b) + "/s"

fun formatGb(gb: Double): String =
    if (gb % 1.0 == 0.0) "${gb.toLong()} Go" else String.format(Locale.FRANCE, "%.1f Go", gb)

fun formatDate(ms: Long): String =
    if (ms <= 0L) "—" else SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(Date(ms))

fun formatDateTime(ms: Long): String = SimpleDateFormat("d MMM · HH:mm", Locale.FRANCE).format(Date(ms))

fun formatDuration(seconds: Long): String {
    val s = seconds.coerceAtLeast(0L)
    return String.format(Locale.FRANCE, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

fun daysLeft(ms: Long): Long = ((ms - System.currentTimeMillis()) / DAY).coerceAtLeast(0L)
